/*============== MOHON DIBACA ==============

BASE SCRIPT : MIECHAN

DI RECODE OLEH : DE4YOU YT

SALURAN DE4YOU YT
https://whatsapp.com/channel/0029Vb2L4fu8KMqpesPWmB17

*/
import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'

global.config = {
    /*============== INFO LINK ==============*/
    instagram: 'https://www.instagram.com/de4younewera',
    github: 'https://github.com/de4you1',
    group: 'https://chat.whatsapp.com/DI256TgP8ZI328IMHghusX',
    website: 'https://de4you1.github.io/listsewabot-website',
    saluran: 'https://whatsapp.com/channel/0029Vb2L4fu8KMqpesPWmB17',


    /*============== PAYMENT ==============*/
    dana: '087778002663',
    ovo: '087778002663',
    gopay: '087778002663',
    pulsa: '087778002663',

    /*============== STAFF ==============*/
    owner: [
        ['6287778002663', 'Owner DE4YOU YT', true]

    ],

    /*============= PAIRING =============*/
    pairingNumber: "6283861553855",
    pairingAuth: true,

    /*============== API ==============*/
    APIs: {
        lol: 'https://api.lolhuman.xyz',
        rose: 'https://api.itsrose.rest',
        xzn: 'https://skizoasia.xyz',
        betabotz : 'https://api.betabotz.eu.org',
    },

    APIKeys: {
        'https://api.lolhuman.xyz': 'de4youyt', //JANGAN UBAH
        'https://api.itsrose.rest': 'Rk-f5d4b183e7dd3dd0a44653678ba5107c', //JANGAN UBAH
        'https://skizoasia.xyz': 'de4youyt', //JANGAN UBAH
        'https://api.betabotz.eu.org': 'de4youyt', //JANGAN UBAH
    },

    /*============== TEXT ==============*/
    watermark: 'Alya-MD V2',
    author: 'DE4YOU YT',
    loading: 'Mohon ditunggu...',
    errorMsg: 'Error :)',

    stickpack: 'Made With',
    stickauth: 'Alya-MD V2 Sewa? Chat : 087778002663',

    digi: {
        username: "",
        apikey: ""
    },

    OK: {
        ID: "_",
        Pin: "_",
        Pass: "_",        
        Apikey: "_"
    },
    
    taxRate: 0.05,
    taxMax: 2000
}

global.loading = (m, conn, back = false) => {
    if (!back) {
        return conn.sendReact(m.chat, "🕒", m.key)
    } else {
        return conn.sendReact(m.chat, "✅", m.key)
    }
}

/*============== EMOJI ==============*/
global.rpg = {
    emoticon(string) {
        string = string.toLowerCase()
        let emot = {
            level: '📊',
            limit: '🎫',
            health: '❤️',
            exp: '✨',
            atm: '💳',
            money: '💰',
            bank: '🏦',
            potion: '🥤',
            diamond: '💎',
            common: '📦',
            uncommon: '🛍️',
            mythic: '🎁',
            legendary: '🗃️',
            superior: '💼',
            pet: '🔖',
            trash: '🗑',
            armor: '🥼',
            sword: '⚔️',
            pickaxe: '⛏️',
            fishingrod: '🎣',
            wood: '🪵',
            rock: '🪨',
            string: '🕸️',
            horse: '🐴',
            cat: '🐱',
            dog: '🐶',
            fox: '🦊',
            robo: '🤖',
            dragon: '🐉',
            lion: '🦁',
            rhinoceros: '🦏',
            centaur: '🦄',
            kyubi: '🦊',
            griffin: '🦅',
            phonix: '🔥',
            wolf: '🐺',
            petfood: '🍖',
            iron: '⛓️',
            gold: '🪙',
            emerald: '❇️',
            upgrader: '🧰',
            bibitanggur: '🌱',
            bibitjeruk: '🌿',
            bibitapel: '☘️',
            bibitmangga: '🍀',
            bibitpisang: '🌴',
            anggur: '🍇',
            jeruk: '🍊',
            apel: '🍎',
            mangga: '🥭',
            pisang: '🍌',
            botol: '🍾',
            kardus: '📦',
            kaleng: '🏮',
            plastik: '📜',
            gelas: '🧋',
            chip: '♋',
            umpan: '🪱',
            skata: '🧩',
            bitcoin: '☸️',
            polygon: '☪️',
            dogecoin: '☯️',
            etherium: '⚛️',
            solana: '✡️',
            memecoin: '☮️',
            donasi: '💸',
            ammn: '⚖️',
            bbca: '💵',
            bbni: '💴',
            cuan: '🧱',
            bbri: '💶',
            msti: '📡',
            steak: '🥩',
            ayam_goreng: '🍗',
            ribs: '🍖',
            roti: '🍞',
            udang_goreng: '🍤',
            bacon: '🥓',
            gandum: '🌾',
            minyak: '🥃',
            garam: '🧂',
            babi: '🐖',
            ayam: '🐓',
            sapi: '🐮',
            udang: '🦐'
        }
        if (typeof emot[string] !== 'undefined') {
            return emot[string]
        } else {
            return ''
        }
    }
}

//------ JANGAN DIUBAH -----
let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
    unwatchFile(file)
    console.log(chalk.redBright("Update 'config.js'"))
    import(`${file}?update=${Date.now()}`)
})
