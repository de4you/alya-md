let linkRegex = /vps|jual|ready|panel|script|sc|sell|1gb|unli|ready panel|sosmed|jasa|suntik|like tiktok|patner panel|owner panel|pt/i // tambahin sendiri
export async function before(m) {
    if (m.isBaileys || m.fromMe) return
    let chat = global.db.data.chats[m.chat]
    let setting = global.db.data.settings[conn.user.jid]

    let isGroupPromosi = linkRegex.exec(m.text)
    if (chat.antiPromosi && isGroupPromosi && m.isGroup) {
        if (setting.composing)
            await this.sendPresenceUpdate('composing', m.chat)
        if (setting.autoread)
        await m.reply('GAK USAH PROMOSI ANJ😂')
        await conn.sendMessage(m.chat, { delete: m.key })
    }
    return !0
}