import fs from 'fs'

let handler = async (m, { conn }) => {
    let pluginFiles = fs.readdirSync('./plugins')
    
    let totalFiles = pluginFiles.length
    let fitur = Object.values(global.plugins).filter(v => v.help && !v.disabled).map(v => v.help).flat(1)
    let totalFitur = fitur.length

    let plugins = Object.values(global.plugins)
    let categories = {}

    for (let plugin of plugins) {
        if (plugin.tags && plugin.help) {
            for (let tag of plugin.tags) {
                if (!categories[tag]) categories[tag] = { files: 0, features: 0 }
                categories[tag].files++
                categories[tag].features += plugin.help.length
            }
        }
    }

    let txt = `🚀 *\`Total Fiture Alya MD\`* 🚀\n\n` +
              `* *Total Files:*    _${totalFiles}_\n` + 
              `* *Total Fitur:*    _${totalFitur}_\n` +
              `* *Name Bot:*  _${global.namebot}_\n` + 
              `* *Creator Alya MD:*  _${global.author}_\n\n`

    conn.reply(m.chat, txt, m)
}

handler.help = ['totalfitur']
handler.tags = ['info']
handler.command = /^(totalfitur|totalfeature|totalcmd)$/i
export default handler