import fs from 'fs'

let handler = async (m, { conn }) => {
	let pfft = " ```🚩 Jika Ingin Membeli Ketik Owner Saja || https://wa.me//6287778002663``` ";
conn.sendMessage(m.chat, {
      text: pfft,
      contextInfo: {
      externalAdReply: {
      title: `The Script In For Sale📥`,
      body: '[❗] Script Ini Tidak Gratis',
      thumbnailUrl: `https://img1.pixhost.to/images/5529/595423642_kyami.jpg`,
      sourceUrl: `https://whatsapp.com/channel/0029Vb2L4fu8KMqpesPWmB17`,
      mediaType: 1,
      renderLargerThumbnail: true
      }}})
}
handler.command = /^(sc|script)$/i;

export default handler;