import fetch from 'node-fetch'
import uploadImage from '../lib/uploadImage.js'

const handler = async (m, { conn, command, usedPrefix }) => {
  let q = m.quoted ? m.quoted : m
  const mime = (q.msg || q).mimetype || ''
  if (!/image/.test(mime)) return m.reply(`Kirim atau reply foto dengan caption *${usedPrefix + command}*`)
  
  try {
    // Reaction ⏳ proses mulai
    await conn.sendMessage(m.chat, {
      react: { text: "⏳", key: m.key }
    })

    const media = await q.download()
    if (!media) throw 'Gagal mendownload gambar'

    // Reaction ⚡ upload mulai
    await conn.sendMessage(m.chat, {
      react: { text: "⚡", key: m.key }
    })

    const uploadedUrl = await uploadImage(media)
    if (!uploadedUrl) throw 'Gagal mengupload gambar'

    const apiUrl = `https://apizell.web.id/tools/hd?url=${encodeURIComponent(uploadedUrl)}`

    // Reaction ✨ enhance mulai
    await conn.sendMessage(m.chat, {
      react: { text: "✨", key: m.key }
    })

    const res = await fetch(apiUrl)
    if (!res.ok) throw 'Gagal mendapatkan respon dari API'

    const json = await res.json()
    if (!json.status || !json.result?.upscaled) throw 'Gagal memproses gambar'

    const bufferHD = await fetch(json.result.upscaled).then(res => res.buffer())
    if (!bufferHD) throw 'Gagal mengambil gambar hasil'

    await conn.sendMessage(m.chat, {
      image: bufferHD,
      caption: '✅ Berhasil di-HD-kan!'
    }, { quoted: m })

    // Reaction ✅ sukses
    await conn.sendMessage(m.chat, {
      react: { text: "✅", key: m.key }
    })

  } catch (e) {
    console.error(e)
    // Reaction ❌ kalau error
    await conn.sendMessage(m.chat, {
      react: { text: "❌", key: m.key }
    })
    m.reply('❌ Terjadi kesalahan, coba lagi nanti.')
  }
}

handler.help = ['hd', 'hdr']
handler.tags = ['ai', 'tools']
handler.command = ['hd', 'hdr']

export default handler