import fs from 'fs'

let handler = async (m, { conn }) => {
	let pfft = " *`▧ 「🦋Alya Whatsapp Bot」`*
╭────────────────━
┃
┃
┃- *💐 MieChan Multi Device*
┃-        *78% All Work*
┃-        *Type Plugins ES Module*
┃-        *AntiTagSw Work*
┃-        *Tupap otomatis dan donasi*
┃-        *Rpg Game All Work*
┃-        *StoreMenu & Addlist*
┃-        *Ai Chat Bots*
┃-        *50% Scrape & 50% Apikey*
┃-        *Button Menu*
┃
┃友 *Chat 1 : https://wa.me/6287778002663*
┃友 *Informasi Fitur Update : https://whatsapp.com/channel/0029VbAzDcXChq6RkzvRKp2k*
╰────────────────━``` ";
conn.sendMessage(m.chat, {
      text: pfft,
      contextInfo: {
      externalAdReply: {
      title: `[ ! ] Buy To Script Bro`,
      body: '[❗] Script Ini Tidak Gratis',
      thumbnailUrl: `https://files.catbox.moe/14enxv.jpg`,
      sourceUrl: `https://whatsapp.com/channel/0029Vb2L4fu8KMqpesPWmB17`,
      mediaType: 1,
      renderLargerThumbnail: true
      }}})
}
handler.command = /^(sc|script)$/i;

export default handler;