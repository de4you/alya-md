.import axios from 'axios'
import fetch from 'node-fetch'
import gis from 'g-i-s';
const {
    proto,
    generateWAMessageFromContent,
    prepareWAMessageMedia, 
    generateWAMessageContent, 
} = (await import('@adiwajshing/baileys')).default
import { googleImage } from '@bochilteam/scraper'

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) return m.reply(`⊏|⊐ *Contoh:* ${usedPrefix + command} Shiroko wangy body`);

  await conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }});

  async function createImage(url) {
    const { imageMessage } = await generateWAMessageContent({
      image: { url }
    }, {
      upload: conn.waUploadToServer
    });
    return imageMessage;
  }

  function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
  }

  let push = [];
  let data = await pinterest(text);
  shuffleArray(data);
  let ult = data.slice(0, 10);
  let i = 1;

  for (let lucuy of ult) {
    push.push({
      body: proto.Message.InteractiveMessage.Body.fromObject({
        text: `Image ke - ${i++}`
      }),
      footer: proto.Message.InteractiveMessage.Footer.fromObject({
        text: wm
      }),
      header: proto.Message.InteractiveMessage.Header.fromObject({
        title: '',
        hasMediaAttachment: true,
        imageMessage: await createImage(lucuy)
      }),
      nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
        buttons: [
          {
            "name": "cta_url",
            "buttonParamsJson": JSON.stringify({ url: lucuy })
          }
        ]
      })
    });
  }

  const bot = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
          body: proto.Message.InteractiveMessage.Body.create({
            text: 'Hasil Dari: ' + text
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: '乂 P I N T - S L I D E'
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            hasMediaAttachment: false
          }),
          carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
            cards: [...push]
          })
        })
      }
    }
  }, { quoted: m });

  await conn.relayMessage(m.chat, bot.message, { messageId: bot.key.id });
  await conn.sendMessage(m.chat, { react: { text: ``, key: m.key }});
}

handler.help = ["pinterest"]
handler.tags = ["downloader"]
handler.command = /^(pinterest|pin)$/i
handler.limit = true
export default handler;

async function pinterest(query) {
    return new Promise((resolve, reject) => {
        gis({ searchTerm: query + ' site:id.pinterest.com' }, (err, res) => {
            if (err) return reject("Terjadi kesalahan dalam mengambil gambar");
            let hasil = res.map(x => x.url);
            if (hasil.length === 0) return reject("Tidak ditemukan hasil untuk pencarian tersebut.");
            resolve(hasil);
        });
    });
}