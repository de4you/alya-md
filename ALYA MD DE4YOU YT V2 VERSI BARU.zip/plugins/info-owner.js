import fs from 'fs'

let handler = async (m, { conn }) => {
	let owner = `_Owner Alya MD_
*Nama Owner : DE4YOU YT*
*Kontak Owner : https://wa.me//6287778002663*

Silakan Pencet Link Kontak Owner Di Atas.
_Jangan Call Dan Spam Owner Yah, Terimakasih._`;
	await conn.sendMessage(m.chat, { image: { url: 'https://img1.pixhost.to/images/5529/595423642_kyami.jpg' }, caption: owner }, m)
}
handler.help = ['owner']
handler.tags = ['owner']
handler.command = /^(owner)$/i;

export default handler;